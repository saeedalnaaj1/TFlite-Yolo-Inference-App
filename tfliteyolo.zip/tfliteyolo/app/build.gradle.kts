plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.tfliteyolo"
    compileSdk = 33   // required for CameraX 1.3.x

    defaultConfig {
        applicationId = "com.example.tfliteyolo"
        minSdk = 21
        targetSdk = 33   // can stay 33
        versionCode = 1
        versionName = "1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions { jvmTarget = "1.8" }

    // Optional but nice
    buildFeatures { viewBinding = true }
}

configurations.all {
    resolutionStrategy {
        force(
            "androidx.core:core:1.10.1",
            "androidx.core:core-ktx:1.10.1",
            "androidx.appcompat:appcompat:1.6.1",
            "androidx.appcompat:appcompat-resources:1.6.1",
            "androidx.activity:activity:1.7.2",
            "androidx.activity:activity-ktx:1.7.2",
            "androidx.fragment:fragment:1.6.2",
            "androidx.fragment:fragment-ktx:1.6.2",
            "androidx.lifecycle:lifecycle-runtime-android:2.6.2",
            "androidx.lifecycle:lifecycle-runtime-ktx:2.6.2",
            "androidx.lifecycle:lifecycle-livedata:2.6.2",
            "androidx.lifecycle:lifecycle-livedata-core:2.6.2",
            "androidx.lifecycle:lifecycle-livedata-core-ktx:2.6.2",
            "androidx.lifecycle:lifecycle-viewmodel-android:2.6.2",
            "androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.2",
            "androidx.lifecycle:lifecycle-process:2.6.2",
            "androidx.lifecycle:lifecycle-viewmodel-savedstate:2.6.2",
            "androidx.savedstate:savedstate:1.2.1",
            "androidx.transition:transition:1.4.1",
            "androidx.annotation:annotation-experimental:1.3.1",
            "androidx.camera:camera-core:1.2.3",
            "androidx.camera:camera-camera2:1.2.3",
            "androidx.camera:camera-lifecycle:1.2.3",
            "androidx.camera:camera-view:1.2.3"
        )
    }
}



dependencies {
    // ---- Core UI (API-33 friendly) ----
    implementation("androidx.core:core:1.10.1")
    implementation("androidx.core:core-ktx:1.10.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.9.0") // ok with 33

    // Fragment/Activity
    implementation("androidx.activity:activity-ktx:1.7.2")
    implementation("androidx.fragment:fragment-ktx:1.6.2")

    // Lifecycle & SavedState
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.6.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.2")
    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.6.2")
    implementation("androidx.savedstate:savedstate:1.2.1")

    // Transition (1.5.0 requires compileSdk 34)
    implementation("androidx.transition:transition:1.4.1")

    // Some libs pull this transitively at 1.4.0 -> force 1.3.1 for compileSdk 33
    implementation("androidx.annotation:annotation-experimental:1.3.1")

    // ---- CameraX pinned to 1.2.3 for compileSdk 33 ----
    val cameraX = "1.2.3"
    implementation("androidx.camera:camera-core:$cameraX")
    implementation("androidx.camera:camera-camera2:$cameraX")
    implementation("androidx.camera:camera-lifecycle:$cameraX")
    implementation("androidx.camera:camera-view:$cameraX")

    // ---- TensorFlow Lite ----
    implementation("org.tensorflow:tensorflow-lite:2.14.0")
    implementation("org.tensorflow:tensorflow-lite-support:0.4.4")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}

