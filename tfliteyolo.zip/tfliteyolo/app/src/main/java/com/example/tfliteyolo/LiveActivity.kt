package com.example.tfliteyolo

import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Bundle
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.nio.ByteBuffer
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

class LiveActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var overlayView: BoxOverlay
    private lateinit var statusText: TextView
    private lateinit var errorText: TextView

    // Slider UI (restored) + toggle
    private lateinit var seekBar: SeekBar
    private lateinit var confText: TextView
    private lateinit var enableSliderCheck: CheckBox

    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalysis: ImageAnalysis? = null
    private val analysisExecutor = Executors.newSingleThreadExecutor()

    private lateinit var model: ModelManager
    private val modelReady = AtomicBoolean(false)

    // Default cutoff when slider is OFF
    private val MIN_CONF = 0.30f

    // Slider state (when ON)
    private var sliderThreshold: Float = 0.30f
    private var sliderEnabled: Boolean = false

    private val MODEL_W = 640
    private val MODEL_H = 640

    // --- Simple hysteresis for top-1 box (anti-flicker) ---
    private var stableBox: BoundingBox? = null
    private var seenCount = 0
    private var missCount = 0
    private val PERSIST_IN  = 2    // frames to confirm appearance
    private val PERSIST_OUT = 2    // frames to confirm disappearance

    private var lastErrorShown: String? = null

    // Helper to get the currently effective threshold
    private fun currentThresh(): Float = if (sliderEnabled) sliderThreshold else MIN_CONF

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_live)

        previewView = findViewById(R.id.previewLive)
        overlayView = findViewById(R.id.overlayView)
        statusText  = findViewById(R.id.liveStatusText)
        errorText   = findViewById(R.id.liveErrorText)

        // Slider + checkbox
        seekBar = findViewById(R.id.seekBarLive)
        confText = findViewById(R.id.confTextLive)
        enableSliderCheck = findViewById(R.id.enableSliderCheck)

        // Initial UI state
        seekBar.progress = (sliderThreshold * 100).toInt()
        confText.text = "%.2f".format(sliderThreshold)
        enableSliderCheck.isChecked = false
        setSliderEnabled(false)

        // Listeners
        enableSliderCheck.setOnCheckedChangeListener { _, isChecked ->
            setSliderEnabled(isChecked)
            // update model threshold immediately
            model.setConfidenceThreshold(currentThresh())
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                sliderThreshold = p / 100f
                confText.text = "%.2f".format(sliderThreshold)
                if (sliderEnabled) model.setConfidenceThreshold(sliderThreshold)
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // Model uses current effective threshold (initially MIN_CONF)
        model = ModelManager(this, "model.tflite", "labels.txt", confidenceThreshold = currentThresh())

        setStatus("Warming up…")
        analysisExecutor.execute {
            try {
                val warm = Bitmap.createBitmap(MODEL_W, MODEL_H, Bitmap.Config.ARGB_8888)
                model.detectWithThreshold(warm, currentThresh())
                modelReady.set(true)
                setStatus("Running")
            } catch (t: Throwable) {
                setStatus("Model load failed")
                showErrorOnce("Warmup", t)
            }
        }

        startCamera()
    }

    private fun setSliderEnabled(enable: Boolean) {
        sliderEnabled = enable
        seekBar.isEnabled = enable
        confText.alpha = if (enable) 1f else 0.5f
    }

    private fun setStatus(s: String) {
        statusText.post { statusText.text = s }
    }

    private fun showErrorOnce(stage: String, t: Throwable) {
        val msg = "[$stage] ${t.javaClass.simpleName}: ${t.localizedMessage ?: "no message"}"
        if (lastErrorShown == msg) return
        lastErrorShown = msg
        errorText.post {
            val joined = (errorText.text.toString() + "\n" + msg).trim().lines().takeLast(12)
            errorText.text = joined.joinToString("\n")
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            cameraProvider = provider

            val preview = Preview.Builder()
                .setTargetRotation(previewView.display.rotation)
                .build()
                .apply { setSurfaceProvider(previewView.surfaceProvider) }

            imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .setTargetResolution(android.util.Size(MODEL_W, MODEL_H))
                .build()
                .also { it.setAnalyzer(analysisExecutor, ::analyzeFrameRgba) }

            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                imageAnalysis
            )
        }, ContextCompat.getMainExecutor(this))
    }

    /** Analyzer that receives RGBA_8888 frames (one plane, 4 bytes per pixel). */
    @OptIn(ExperimentalGetImage::class)
    private fun analyzeFrameRgba(imageProxy: ImageProxy) {
        try {
            if (!modelReady.get()) return

            val planes = imageProxy.planes
            if (planes.isEmpty()) {
                setStatus("E0:no planes"); postBoxes(emptyList()); return
            }

            val plane = planes[0]
            val width = imageProxy.width
            val height = imageProxy.height
            val rowStride = plane.rowStride
            val pixelStride = plane.pixelStride // should be 4
            if (pixelStride != 4) {
                setStatus("E0:pixelStride=$pixelStride"); postBoxes(emptyList()); return
            }

            // Pack to tight RGBA
            val tightRow = width * 4
            val tight = ByteArray(tightRow * height)
            val buf = plane.buffer
            for (row in 0 until height) {
                val srcPos = row * rowStride
                val dstPos = row * tightRow
                absoluteCopy(buf, srcPos, tight, dstPos, tightRow)
            }

            // Build bitmap
            val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(ByteBuffer.wrap(tight))

            // Rotate if needed
            val deg = imageProxy.imageInfo.rotationDegrees.toFloat()
            val rotated = if (deg != 0f) {
                val m = Matrix().apply { postRotate(deg) }
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
            } else bmp

            // Resize to model input (keep 640x640)
            val input = if (rotated.width == MODEL_W && rotated.height == MODEL_H)
                rotated else Bitmap.createScaledBitmap(rotated, MODEL_W, MODEL_H, true)

            // Use current effective threshold (slider or default)
            val thr = currentThresh()

            // Infer: take ONLY the most confident box (no NMS), then apply hysteresis
            val candidates = model.detectWithThreshold(input, thr, applyNms = false)
            val best = candidates.maxByOrNull { it.confidence }

            // Dynamic hysteresis thresholds around the chosen thr
            val showThr = max(thr, 0.30f)
            val hideThr = max(0.05f, showThr - 0.10f)

            // ---- HYSTERESIS ----
            val next = best

            if (next != null && next.confidence >= showThr) {
                val same = stableBox?.let { iou(it, next) } ?: 0f
                if (stableBox == null || same >= 0.5f) {
                    seenCount++
                    missCount = 0
                    if (seenCount >= PERSIST_IN) stableBox = next
                } else {
                    // jumped elsewhere → accept but re-confirm
                    seenCount = 1
                    missCount = 0
                    stableBox = next
                }
            } else if (stableBox != null && next != null && next.confidence >= hideThr) {
                // soft hold: don't change state yet
                missCount = 0
            } else {
                missCount++
                if (missCount >= PERSIST_OUT) {
                    stableBox = null
                    seenCount = 0
                }
            }

            val toDraw = stableBox?.let { listOf(it) } ?: emptyList()
            postBoxes(toDraw)
            setStatus(if (toDraw.isEmpty()) "Running: 0 boxes" else "Running: 1 box")

        } catch (t: Throwable) {
            showErrorOnce("ANALYZE", t)
            setStatus("Analyzer error")
            postBoxes(emptyList())
        } finally {
            imageProxy.close()
        }
    }

    private fun absoluteCopy(src: ByteBuffer, srcPos: Int, dst: ByteArray, dstPos: Int, length: Int) {
        val old = src.position()
        src.position(srcPos)
        src.get(dst, dstPos, length)
        src.position(old)
    }

    private fun postBoxes(boxes: List<BoundingBox>) {
        overlayView.post { overlayView.setDetections(boxes, MODEL_W, MODEL_H) }
    }

    private fun iou(a: BoundingBox, b: BoundingBox): Float {
        val x1 = max(a.left, b.left)
        val y1 = max(a.top, b.top)
        val x2 = min(a.right, b.right)
        val y2 = min(a.bottom, b.bottom)
        val iw = (x2 - x1).coerceAtLeast(0f)
        val ih = (y2 - y1).coerceAtLeast(0f)
        val inter = iw * ih
        val areaA = (a.right - a.left).coerceAtLeast(0f) * (a.bottom - a.top).coerceAtLeast(0f)
        val areaB = (b.right - b.left).coerceAtLeast(0f) * (b.bottom - b.top).coerceAtLeast(0f)
        val denom = areaA + areaB - inter
        return if (denom <= 0f) 0f else inter / denom
    }

    override fun onDestroy() {
        cameraProvider?.unbindAll()
        imageAnalysis?.clearAnalyzer()
        analysisExecutor.shutdown()
        model.close()
        super.onDestroy()
    }
}
