    package com.example.tfliteyolo

    import android.graphics.*
    import androidx.camera.core.ImageProxy
    import java.io.ByteArrayOutputStream
    import java.nio.ByteBuffer

    /**
     * Simple YUV_420_888 -> Bitmap converter with no RenderScript.
     * Uses NV21 + JPEG roundtrip; slower than GPU paths but stable on all SDKs.
     */
    class YuvToRgbConverter {

        fun toBitmap(image: ImageProxy): Bitmap {
            val nv21 = yuv420ToNv21(image)
            val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
            val out = ByteArrayOutputStream()
            yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 100, out)
            val bytes = out.toByteArray()
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        }

        private fun yuv420ToNv21(image: ImageProxy): ByteArray {
            val yBuffer = image.planes[0].buffer   // Y
            val uBuffer = image.planes[1].buffer   // U
            val vBuffer = image.planes[2].buffer   // V

            val ySize = yBuffer.remaining()
            val uSize = uBuffer.remaining()
            val vSize = vBuffer.remaining()

            val nv21 = ByteArray(ySize + uSize + vSize)
            // U and V are swapped for NV21
            yBuffer.get(nv21, 0, ySize)
            val chromaRowStride = image.planes[1].rowStride
            val chromaRowPadding = chromaRowStride - image.planes[1].pixelStride * (image.width / 2)

            var offset = ySize
            val uRow = ByteArray(chromaRowStride)
            val vRow = ByteArray(image.planes[2].rowStride)

            val w = image.width
            val h = image.height
            for (row in 0 until h / 2) {
                uBuffer.get(uRow, 0, chromaRowStride)
                vBuffer.get(vRow, 0, image.planes[2].rowStride)
                var col = 0
                while (col < w / 2) {
                    nv21[offset++] = vRow[col * image.planes[2].pixelStride]
                    nv21[offset++] = uRow[col * image.planes[1].pixelStride]
                    col++
                }
                // skip row padding
                uBuffer.position(uBuffer.position() + chromaRowPadding)
            }
            return nv21
        }
    }
