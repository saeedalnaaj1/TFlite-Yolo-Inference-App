package com.example.tfliteyolo

import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Size
import android.view.Surface
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.nio.ByteBuffer
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class CaptureActivity : AppCompatActivity() {

    // UI (must exist in res/layout/activity_capture.xml)
    private lateinit var previewView: PreviewView
    private lateinit var captureBtn: Button
    private lateinit var retakeBtn: Button
    private lateinit var useBtn: Button
    private lateinit var saveBtn: Button
    private lateinit var reviewImage: ImageView
    private lateinit var reviewPanel: View
    private lateinit var seekBar: SeekBar
    private lateinit var confText: TextView

    // CameraX
    private var cameraProvider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null

    // Model & state
    private lateinit var model: ModelManager
    private var threshold: Float = 0.50f
    private var capturedScaled640: Bitmap? = null       // cached, scaled once (640x640)
    private var annotatedBitmap: Bitmap? = null

    // Converters
    private val yuvConverter = YuvToRgbConverter() // NO-ARG ctor per your project

    // Perf: background thread + main handler
    private lateinit var workExecutor: ExecutorService
    private val mainHandler = Handler(Looper.getMainLooper())

    // Debounce & staleness control
    private val debounceRunnable = Runnable { kickOffRender() }
    private val renderVersion = AtomicInteger(0)    // increases on each request

    // Reusable paints (no reallocation every frame)
    private val boxPaint = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 4f }
    private val textPaint = Paint().apply { color = Color.WHITE; textSize = 48f; typeface = Typeface.DEFAULT_BOLD }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_capture)

        workExecutor = Executors.newSingleThreadExecutor()

        // bind views
        previewView = findViewById(R.id.previewView)
        captureBtn  = findViewById(R.id.captureButton)
        retakeBtn   = findViewById(R.id.retakeButton)
        useBtn      = findViewById(R.id.useButton)
        saveBtn     = findViewById(R.id.saveButton2)
        reviewImage = findViewById(R.id.reviewImage)
        reviewPanel = findViewById(R.id.reviewPanel)
        seekBar     = findViewById(R.id.seekBar2)
        confText    = findViewById(R.id.confText2)

        model = ModelManager(this, "model.tflite", "labels.txt", confidenceThreshold = threshold)

        // slider
        seekBar.progress = (threshold * 100).toInt()
        confText.text = "Confidence: %.2f".format(threshold)
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                threshold = p / 100f
                confText.text = "Confidence: %.2f".format(threshold)
                model.setConfidenceThreshold(threshold)

                // Debounce re-render to avoid hammering the UI/inference
                mainHandler.removeCallbacks(debounceRunnable)
                mainHandler.postDelayed(debounceRunnable, 120L) // ~8 FPS while sliding
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {
                // ensure a final render after the user stops sliding
                mainHandler.removeCallbacks(debounceRunnable)
                mainHandler.post(debounceRunnable)
            }
        })

        // buttons
        captureBtn.setOnClickListener { capturePhoto() }
        retakeBtn.setOnClickListener { retake() }
        useBtn.setOnClickListener { kickOffRender() /* render current photo with current threshold */ }
        saveBtn.setOnClickListener {
            annotatedBitmap?.let {
                if (saveToGallery(it)) toast("Saved to gallery") else toast("Save failed")
            } ?: toast("Nothing to save")
        }

        showPreviewMode()
        startCamera()
    }

    private fun toast(msg: String) =
        Toast.makeText(this@CaptureActivity, msg, Toast.LENGTH_SHORT).show()

    private fun showPreviewMode() {
        previewView.visibility = View.VISIBLE
        captureBtn.visibility = View.VISIBLE
        reviewPanel.visibility = View.GONE
    }

    private fun showReviewMode() {
        previewView.visibility = View.GONE
        captureBtn.visibility = View.GONE
        reviewPanel.visibility = View.VISIBLE
    }

    private fun retake() {
        // Clear cached bitmaps to free memory
        annotatedBitmap?.recycle()
        annotatedBitmap = null
        capturedScaled640?.recycle()
        capturedScaled640 = null

        showPreviewMode()
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this@CaptureActivity)
        providerFuture.addListener({
            val provider = providerFuture.get()
            cameraProvider = provider

            val preview = Preview.Builder().build().apply {
                setSurfaceProvider(previewView.surfaceProvider)
            }

            imageCapture = ImageCapture.Builder()
                .setTargetResolution(Size(1280, 720))
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                .build()

            provider.unbindAll()
            provider.bindToLifecycle(
                this@CaptureActivity,
                CameraSelector.DEFAULT_BACK_CAMERA,
                preview,
                imageCapture
            )
        }, ContextCompat.getMainExecutor(this@CaptureActivity))
    }

    private fun capturePhoto() {
        val ic = imageCapture ?: return
        ic.takePicture(
            ContextCompat.getMainExecutor(this@CaptureActivity),
            object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    try {
                        val raw = proxyToBitmap(image)
                        val deg = image.imageInfo.rotationDegrees.toFloat()
                        val rotated = if (deg != 0f) {
                            val m = Matrix().apply { postRotate(deg) }
                            Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                        } else raw

                        // Scale ONCE to model size and cache it
                        capturedScaled640?.recycle()
                        capturedScaled640 = if (rotated.width == 640 && rotated.height == 640) {
                            rotated
                        } else {
                            Bitmap.createScaledBitmap(rotated, 640, 640, true)
                        }

                        reviewImage.setImageBitmap(capturedScaled640)
                        showReviewMode()

                        // Trigger initial render in background
                        kickOffRender()
                    } catch (e: Exception) {
                        toast("Capture convert failed: ${e.message}")
                    } finally {
                        image.close()
                    }
                }
                override fun onError(exception: ImageCaptureException) {
                    toast("Capture failed: ${exception.message}")
                }
            }
        )
    }

    private fun proxyToBitmap(image: ImageProxy): Bitmap {
        return when (image.format) {
            android.graphics.ImageFormat.JPEG -> {
                val buffer: ByteBuffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
            android.graphics.ImageFormat.YUV_420_888 -> {
                yuvConverter.toBitmap(image)
            }
            else -> {
                val buffer = image.planes[0].buffer
                val bytes = ByteArray(buffer.remaining())
                buffer.get(bytes)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }
        }
    }

    /**
     * Schedule a background render of the current (scaled) photo with current threshold.
     * Uses a monotonically increasing version so stale work is dropped.
     */
    private fun kickOffRender() {
        val base = capturedScaled640 ?: return
        val myVersion = renderVersion.incrementAndGet()

        workExecutor.execute {
            // 1) Run detection (top-1 as before)
            val best = model.detectSingle(base)

            // 2) If a newer task started, drop this work
            if (myVersion != renderVersion.get()) return@execute

            // 3) Compose annotated bitmap off the UI thread
            val out = if (best == null) {
                // no detection -> just return the base to show
                base.copy(Bitmap.Config.ARGB_8888, true)
            } else {
                val canvasBmp = base.copy(Bitmap.Config.ARGB_8888, true)
                val canvas = Canvas(canvasBmp)

                // ✅ Color from class id (0 -> GREEN, 1 -> RED, else rainbow)
                boxPaint.color = model.colorForClass(best.clsId)

                // draw
                canvas.drawRect(best.left, best.top, best.right, best.bottom, boxPaint)
                val labelText = "${best.label} ${(best.confidence * 100).toInt()}%"
                val textY = (best.top - 10).coerceAtLeast(50f)
                canvas.drawText(labelText, best.left, textY, textPaint)

                canvasBmp
            }

            // 4) Still latest? push to UI
            if (myVersion != renderVersion.get()) return@execute
            mainHandler.post {
                annotatedBitmap?.recycle()
                annotatedBitmap = out
                reviewImage.setImageBitmap(out)
                if (best == null) {
                    toast("No detections above threshold")
                }
            }
        }
    }

    // (Optional) rotation helper if ever needed for previewView.display.rotation
    private fun rotateToDisplay(bmp: Bitmap, rotation: Int): Bitmap {
        val deg = when (rotation) {
            Surface.ROTATION_0 -> 0f
            Surface.ROTATION_90 -> 90f
            Surface.ROTATION_180 -> 180f
            Surface.ROTATION_270 -> 270f
            else -> 0f
        }
        if (deg == 0f) return bmp
        val m = Matrix().apply { postRotate(deg) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    // Save (same behavior as before)
    private fun saveToGallery(bitmap: Bitmap): Boolean {
        return try {
            val filename = "DET_${java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())}.jpg"
            val mime = "image/jpeg"
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(android.provider.MediaStore.Images.Media.MIME_TYPE, mime)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    put(android.provider.MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GaugeInference")
                    put(android.provider.MediaStore.Images.Media.IS_PENDING, 1)
                }
            }
            val uri = contentResolver.insert(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                ?: return false
            contentResolver.openOutputStream(uri)?.use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out)
            }
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                values.clear()
                values.put(android.provider.MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace(); false
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(debounceRunnable)
        cameraProvider?.unbindAll()
        workExecutor.shutdown()
        annotatedBitmap?.recycle()
        capturedScaled640?.recycle()
        model.close()
        super.onDestroy()
    }
}
