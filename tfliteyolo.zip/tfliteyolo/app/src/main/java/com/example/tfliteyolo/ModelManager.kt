package com.example.tfliteyolo

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import org.tensorflow.lite.support.common.ops.NormalizeOp
import org.tensorflow.lite.support.image.ImageProcessor
import org.tensorflow.lite.support.image.TensorImage
import kotlin.math.max
import kotlin.math.min

data class BoundingBox(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val confidence: Float,
    val label: String,
    val clsId: Int
)

class ModelManager(
    private val context: Context,
    modelFile: String,
    labelFile: String,
    private var confidenceThreshold: Float = 0.6f,
    private val inputWidth: Int = 640,
    private val inputHeight: Int = 640,
    private val useLetterbox: Boolean = false  // false: stretch to 640x640, true: letterbox pad
) {
    private val interpreter: Interpreter
    private val labels: List<String>

    private val imgProcessor = ImageProcessor.Builder()
        .add(NormalizeOp(0f, 255f))   // float models 0..1
        .build()

    init {
        val model = FileUtil.loadMappedFile(context, modelFile)
        interpreter = Interpreter(model, Interpreter.Options().apply { setNumThreads(4) })
        labels = FileUtil.loadLabels(context, labelFile)
    }

    fun setConfidenceThreshold(th: Float) { confidenceThreshold = th }
    fun close() { interpreter.close() }

    fun detectSingle(originalBitmap: Bitmap): BoundingBox? {
        val boxes = runModelAndParse(originalBitmap, confidenceThreshold, applyNms = false)
        return boxes.maxByOrNull { it.confidence }
    }

    fun detectWithThreshold(originalBitmap: Bitmap, threshold: Float, applyNms: Boolean = false): List<BoundingBox> {
        return runModelAndParse(originalBitmap, threshold, applyNms)
    }

    // ---------------- core ----------------

    private data class PreprocResult(
        val bmp: Bitmap,
        val scaleX: Float, val scaleY: Float,
        val padX: Float, val padY: Float
    )

    private fun preprocess(bmp: Bitmap): PreprocResult {
        if (!useLetterbox) {
            val resized = if (bmp.width != inputWidth || bmp.height != inputHeight) {
                Bitmap.createScaledBitmap(bmp, inputWidth, inputHeight, true)
            } else bmp
            return PreprocResult(resized, bmp.width.toFloat()/inputWidth, bmp.height.toFloat()/inputHeight, 0f, 0f)
        }

        // letterbox to input size
        val r = min(inputWidth.toFloat()/bmp.width, inputHeight.toFloat()/bmp.height)
        val newW = (bmp.width * r).toInt()
        val newH = (bmp.height * r).toInt()
        val resized = Bitmap.createScaledBitmap(bmp, newW, newH, true)

        val padded = Bitmap.createBitmap(inputWidth, inputHeight, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(padded)
        c.drawColor(android.graphics.Color.rgb(114,114,114))
        val dx = ((inputWidth - newW) / 2f)
        val dy = ((inputHeight - newH) / 2f)
        c.drawBitmap(resized, dx, dy, null)

        return PreprocResult(
            bmp = padded,
            scaleX = 1f / r,
            scaleY = 1f / r,
            padX = dx,
            padY = dy
        )
    }

    private fun runModelAndParse(originalBitmap: Bitmap, thresh: Float, applyNms: Boolean): List<BoundingBox> {
        // --- preprocess ---
        val prep = preprocess(originalBitmap)
        val tensorImage = TensorImage(DataType.FLOAT32)
        tensorImage.load(prep.bmp)
        val processed = imgProcessor.process(tensorImage)
        val inputBuffer = processed.buffer.rewind()

        // --- run ---
        val outTensor = interpreter.getOutputTensor(0)
        val outShape = outTensor.shape() // [1, A, B]
        require(outShape.size == 3 && outShape[0] == 1) { "Unexpected output shape: ${outShape.contentToString()}" }

        val A = outShape[1]
        val B = outShape[2]
        val outArray = Array(1) { Array(A) { FloatArray(B) } }
        interpreter.run(inputBuffer, outArray)

        val rows = normalizeOutputLayoutToRows(outArray)  // -> List<FloatArray> of [cx,cy,w,h,(obj),c...]

        // --- parse with OBJ x CLASS ---
        val numClasses = labels.size
        val boxes = ArrayList<BoundingBox>(rows.size)
        fun sig(x: Float): Float = 1f / (1f + kotlin.math.exp(-x))

        for (det in rows) {
            // Expect: [cx, cy, w, h, (obj), class0, class1, ...]
            if (det.size < 4 + numClasses) continue

            val cx = det[0]; val cy = det[1]; val w = det[2]; val h = det[3]
            if (w <= 0f || h <= 0f) continue

            val hasObj = det.size >= 5 + numClasses
            val objLogitOrProb = if (hasObj) det[4] else 1f
            val obj = if (hasObj) sig(objLogitOrProb) else objLogitOrProb

            var bestScore = -Float.MAX_VALUE
            var bestCls = 0
            val classStart = if (hasObj) 5 else 4

            for (c in 0 until numClasses) {
                val clsProb = sig(det[classStart + c])     // safe even if already ~[0,1]
                val score = obj * clsProb                  // <-- key change
                if (score > bestScore) { bestScore = score; bestCls = c }
            }

            if (bestScore < thresh) continue

            // cxcywh (0..1) -> xyxy in model space
            val leftR = (cx - w/2f) * inputWidth
            val topR = (cy - h/2f) * inputHeight
            val rightR = (cx + w/2f) * inputWidth
            val bottomR = (cy + h/2f) * inputHeight

            // Map back to original
            val (l0, t0, r0, b0) = if (!useLetterbox) {
                val sx = originalBitmap.width.toFloat() / inputWidth
                val sy = originalBitmap.height.toFloat() / inputHeight
                arrayOf(leftR*sx, topR*sy, rightR*sx, bottomR*sy)
            } else {
                val lx = (leftR - prep.padX) * prep.scaleX
                val tx = (topR - prep.padY) * prep.scaleY
                val rx = (rightR - prep.padX) * prep.scaleX
                val bx = (bottomR - prep.padY) * prep.scaleY
                arrayOf(lx, tx, rx, bx)
            }

            val cl = clamp(l0, 0f, originalBitmap.width.toFloat())
            val ct = clamp(t0, 0f, originalBitmap.height.toFloat())
            val cr = clamp(r0, 0f, originalBitmap.width.toFloat())
            val cb = clamp(b0, 0f, originalBitmap.height.toFloat())
            if (cr <= cl || cb <= ct) continue

            // Optional: drop tiny boxes (0.5% of image) to suppress speckles
            val area = (cr - cl) * (cb - ct)
            val minArea = 0.005f * originalBitmap.width * originalBitmap.height
            if (area < minArea) continue

            boxes += BoundingBox(
                left = cl, top = ct, right = cr, bottom = cb,
                confidence = bestScore,
                label = labels.getOrNull(bestCls) ?: bestCls.toString(),
                clsId = bestCls
            )
        }

        if (!applyNms) return boxes
        return nmsPerClass(boxes, iouThresh = 0.50f)
    }

    private fun clamp(v: Float, lo: Float, hi: Float) = max(lo, min(hi, v))

    private fun normalizeOutputLayoutToRows(out: Array<Array<FloatArray>>): List<FloatArray> {
        val a = out[0].size
        val b = out[0][0].size
        return if (a in 5..7 && b > a) {
            // (1, A, B) -> (B, A)  e.g., YOLO head packed as channels-first
            List(b) { i -> FloatArray(a) { c -> out[0][c][i] } }
        } else {
            // (1, N, channels) -> (N, channels)
            List(a) { i -> out[0][i] }
        }
    }

    // ------- NMS (per-class) for optional multi-box mode -------
    private fun nmsPerClass(input: List<BoundingBox>, iouThresh: Float): List<BoundingBox> {
        val byCls = input.groupBy { it.clsId }
        val kept = mutableListOf<BoundingBox>()
        for ((_, list) in byCls) {
            val sorted = list.sortedByDescending { it.confidence }.toMutableList()
            while (sorted.isNotEmpty()) {
                val a = sorted.removeAt(0)
                kept += a
                val it = sorted.iterator()
                while (it.hasNext()) {
                    val b = it.next()
                    if (iou(a, b) > iouThresh) it.remove()
                }
            }
        }
        return kept
    }

    private fun iou(a: BoundingBox, b: BoundingBox): Float {
        val xA = max(a.left, b.left)
        val yA = max(a.top, b.top)
        val xB = min(a.right, b.right)
        val yB = min(a.bottom, b.bottom)
        val inter = max(0f, xB - xA) * max(0f, yB - yA)
        val areaA = (a.right - a.left) * (a.bottom - a.top)
        val areaB = (b.right - b.left) * (b.bottom - b.top)
        val denom = areaA + areaB - inter
        return if (denom <= 0f) 0f else inter / denom
    }

    // Class → color (0 green, 1 red; fallback rainbow)
    fun colorForClass(cls: Int): Int {
        return when (cls) {
            0 -> android.graphics.Color.GREEN
            1 -> android.graphics.Color.RED
            else -> android.graphics.Color.rgb((37*cls)%255, (91*cls)%255, (173*cls)%255)
        }
    }
}
