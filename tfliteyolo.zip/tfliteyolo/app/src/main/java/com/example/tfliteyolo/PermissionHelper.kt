package com.example.tfliteyolo

import android.app.Activity
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

object PermissionHelper {
    private const val REQ = 42
    private var callback: ((Boolean) -> Unit)? = null

    fun ensureCamera(activity: Activity, cb: (Boolean)->Unit) {
        val perm = android.Manifest.permission.CAMERA
        if (ContextCompat.checkSelfPermission(activity, perm) == PackageManager.PERMISSION_GRANTED) {
            cb(true); return
        }
        callback = cb
        ActivityCompat.requestPermissions(activity, arrayOf(perm), REQ)
    }

    fun onRequestPermissionsResult(requestCode: Int, grantResults: IntArray) {
        if (requestCode != REQ) return
        callback?.invoke(grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)
        callback = null
    }
}
