package com.example.tfliteyolo

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

class BoxOverlay @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Color.RED
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 36f
    }

    private var boxes: List<BoundingBox> = emptyList()
    private var srcW: Int = 640
    private var srcH: Int = 640

    /**
     * Provide detections in **model coordinate space** (srcW x srcH),
     * typically 640x640. The overlay will transform them to view space
     * using the same "fill-center" logic as PreviewView.
     */
    fun setDetections(list: List<BoundingBox>, srcWidth: Int, srcHeight: Int) {
        boxes = list
        srcW = srcWidth
        srcH = srcHeight
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (boxes.isEmpty()) return

        val vw = width.toFloat()
        val vh = height.toFloat()
        if (vw <= 0f || vh <= 0f) return

        // FILL-CENTER: scale to fill, keep aspect, crop the excess, center it
        val scale = max(vw / srcW, vh / srcH)
        val drawW = srcW * scale
        val drawH = srcH * scale
        val offsetX = (vw - drawW) / 2f
        val offsetY = (vh - drawH) / 2f

        for (b in boxes) {
            // ✅ Per-class color: class 0 (normal) = GREEN, class 1 = RED, else fallback rainbow
            stroke.color = colorForClass(b.clsId)

            val l = offsetX + b.left * scale
            val t = offsetY + b.top * scale
            val r = offsetX + b.right * scale
            val bb = offsetY + b.bottom * scale

            canvas.drawRect(l, t, r, bb, stroke)
            val label = "${b.label} ${(b.confidence * 100).toInt()}%"
            canvas.drawText(label, l.coerceAtLeast(8f), (t - 8f).coerceAtLeast(24f), text)
        }
    }

    // Same palette as ModelManager.colorForClass to keep consistency
    private fun colorForClass(cls: Int): Int {
        return when (cls) {
            0 -> Color.GREEN
            1 -> Color.RED
            else -> Color.rgb((37 * cls) % 255, (91 * cls) % 255, (173 * cls) % 255)
        }
    }
}
