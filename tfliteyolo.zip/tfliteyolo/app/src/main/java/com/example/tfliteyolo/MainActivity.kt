package com.example.tfliteyolo

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var modelManager: ModelManager
    private lateinit var imageView: ImageView
    private lateinit var logTextView: TextView
    private lateinit var seekBar: SeekBar
    private lateinit var confidenceText: TextView
    private lateinit var checkbox: CheckBox

    private lateinit var pickBtn: Button
    private lateinit var saveBtn: Button
    private lateinit var captureBtn: Button
    private lateinit var liveBtn: Button

    private var rawBitmap: Bitmap? = null
    private var annotatedBitmap: Bitmap? = null
    private var showConfidenceSlider = false
    private var confidenceThreshold = 0.3f
    private var originalLog: String = ""

    // For gallery pick (legacy approach preserved for your app flow)
    private val pickImageLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            val data: Intent? = res.data
            val uri: Uri? = data?.data
            if (uri != null) {
                val bmp = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                // Force resize to 640x640 (keeps current behavior)
                rawBitmap = Bitmap.createScaledBitmap(bmp, 640, 640, true)
                runDetection(rawBitmap!!)
            }
        }
    }

    // Camera permission launcher for capture/live buttons
    private var pendingCameraAction: (() -> Unit)? = null
    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            pendingCameraAction?.invoke()
        } else {
            Toast.makeText(this, "Camera permission is required.", Toast.LENGTH_SHORT).show()
        }
        pendingCameraAction = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        logTextView = findViewById(R.id.logTextView)
        seekBar = findViewById(R.id.seekBar)
        confidenceText = findViewById(R.id.confidenceText)
        checkbox = findViewById(R.id.checkbox)
        pickBtn = findViewById(R.id.pickButton)
        saveBtn = findViewById(R.id.saveButton)
        captureBtn = findViewById(R.id.captureButton)
        liveBtn = findViewById(R.id.liveButton)

        // Model: keep current FLOAT32 pipeline; set useLetterbox=false by default (you can flip later)
        modelManager = ModelManager(
            context = this,
            modelFile = "model.tflite",
            labelFile = "labels.txt",
            confidenceThreshold = confidenceThreshold,
            useLetterbox = false
        )

        // Checkbox toggles visibility of the slider
        checkbox.isChecked = false
        toggleSeekBarVisibility(false)
        checkbox.setOnCheckedChangeListener { _, isChecked ->
            showConfidenceSlider = isChecked
            toggleSeekBarVisibility(isChecked)
            rawBitmap?.let { runDetection(it) }
        }

        seekBar.progress = (confidenceThreshold * 100).toInt()
        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                confidenceThreshold = p / 100f
                confidenceText.text = String.format("Confidence: %.2f", confidenceThreshold)
                modelManager.setConfidenceThreshold(confidenceThreshold)
                rawBitmap?.let { updateDetection(it) }
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })

        pickBtn.setOnClickListener {
            val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI)
            pickImageLauncher.launch(intent)
        }

        saveBtn.setOnClickListener {
            annotatedBitmap?.let {
                if (saveToGallery(it)) {
                    Toast.makeText(this, "Saved to gallery", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Save failed", Toast.LENGTH_SHORT).show()
                }
            } ?: Toast.makeText(this, "No image to save", Toast.LENGTH_SHORT).show()
        }

        captureBtn.setOnClickListener {
            ensureCameraThen {
                startActivity(Intent(this, CaptureActivity::class.java))
            }
        }

        liveBtn.setOnClickListener {
            ensureCameraThen {
                startActivity(Intent(this, LiveActivity::class.java))
            }
        }
    }

    private fun ensureCameraThen(action: () -> Unit) {
        val granted = ContextCompat.checkSelfPermission(
            this, Manifest.permission.CAMERA
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (granted) {
            action()
        } else {
            pendingCameraAction = action
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    private fun toggleSeekBarVisibility(show: Boolean) {
        seekBar.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
        confidenceText.visibility = if (show) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun runDetection(bmp: Bitmap) {
        val best = modelManager.detectSingle(bmp)
        val canvasBmp = bmp.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(canvasBmp)
        val paint = Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 4f
            color = Color.RED // will be overwritten below if class colors are used
        }
        val textPaint = Paint().apply {
            color = Color.RED
            textSize = 48f
            typeface = Typeface.DEFAULT_BOLD
        }

        val logEntries = mutableListOf<String>()

        if (best == null) {
            Toast.makeText(this, "No detections above threshold", Toast.LENGTH_SHORT).show()
            originalLog = ""
        } else {
            // Per your rule: class 0 green, class 1 red
            val clr = modelManager.colorForClass(best.clsId)
            paint.color = clr
            textPaint.color = Color.WHITE

            canvas.drawRect(best.left, best.top, best.right, best.bottom, paint)
            canvas.drawText("${best.label} ${(best.confidence * 100).toInt()}%",
                best.left, (best.top - 10).coerceAtLeast(40f), textPaint)

            logEntries.add(
                "Class: ${best.label}, Confidence: ${(best.confidence * 100).toInt()}%, " +
                        "Coordinates: [${best.left}, ${best.top}, ${best.right}, ${best.bottom}]"
            )
            originalLog = logEntries.joinToString("\n")
        }

        logTextView.text = originalLog
        annotatedBitmap = canvasBmp
        imageView.setImageBitmap(canvasBmp)
    }

    private fun updateDetection(bmp: Bitmap) {
        // When slider is visible, show all boxes above threshold (like your live behavior),
        // but still draw them here for the static image.
        val boxes = modelManager.detectWithThreshold(bmp, confidenceThreshold, applyNms = true)

        val canvasBmp = bmp.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(canvasBmp)
        val paint = Paint().apply {
            style = Paint.Style.STROKE
            strokeWidth = 4f
            color = Color.RED
        }
        val textPaint = Paint().apply {
            color = Color.WHITE
            textSize = 48f
            typeface = Typeface.DEFAULT_BOLD
        }

        val logs = mutableListOf<String>()
        for (b in boxes) {
            paint.color = modelManager.colorForClass(b.clsId)
            canvas.drawRect(b.left, b.top, b.right, b.bottom, paint)
            canvas.drawText("${b.label} ${(b.confidence * 100).toInt()}%",
                b.left, (b.top - 10).coerceAtLeast(40f), textPaint)
            logs.add(
                "Class: ${b.label}, Confidence: ${(b.confidence * 100).toInt()}%, " +
                        "Coordinates: [${b.left}, ${b.top}, ${b.right}, ${b.bottom}]"
            )
        }

        originalLog = logs.joinToString("\n")
        logTextView.text = originalLog
        annotatedBitmap = canvasBmp
        imageView.setImageBitmap(canvasBmp)
    }

    private fun saveToGallery(bitmap: Bitmap): Boolean {
        val filename = "DET_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val mime = "image/jpeg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/GaugeInference")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val uri: Uri? = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        uri ?: return false

        return try {
            contentResolver.openOutputStream(uri)?.use { out: OutputStream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, out)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        modelManager.close()
    }
}
