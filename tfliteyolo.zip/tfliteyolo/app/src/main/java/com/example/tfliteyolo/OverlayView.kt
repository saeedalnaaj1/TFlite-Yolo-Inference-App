package com.example.tfliteyolo

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class aOverlayView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    data class BoxDraw(
        val left: Float, val top: Float, val right: Float, val bottom: Float,
        val label: String, val conf: Float, val color: Int
    )

    private val boxes = mutableListOf<BoxDraw>()
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 42f
        typeface = Typeface.DEFAULT_BOLD
    }
    private val textBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(140, 0, 0, 0)
    }

    fun setBoxes(list: List<BoxDraw>) {
        synchronized(boxes) {
            boxes.clear()
            boxes.addAll(list)
        }
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val copy: List<BoxDraw> = synchronized(boxes) { boxes.toList() }

        for (b in copy) {
            boxPaint.color = b.color
            canvas.drawRect(b.left, b.top, b.right, b.bottom, boxPaint)

            val text = "${b.label} ${(b.conf * 100).toInt()}%"
            textPaint.color = Color.WHITE
            val pad = 8f
            val tw = textPaint.measureText(text)
            val th = textPaint.fontMetrics.run { bottom - top }
            val tx = b.left
            val ty = (b.top - 10).coerceAtLeast(th + 10)

            // draw bg
            canvas.drawRect(tx - pad, ty - th - pad, tx + tw + pad, ty + pad, textBgPaint)
            canvas.drawText(text, tx, ty - 6, textPaint)
        }
    }
}
